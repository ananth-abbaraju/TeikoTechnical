### 2. What would be some advantages in capturing this information in a database?

By capturing this information in a database, most importantly, we establish a robust way to store extremely large amounts of data. This way, when we need to analyze some relationship, we can easily query based on a certain criteria, whether that be the subjects' conditions, treatment, or anything else. It also serves to preprocess our data, making sure it fits the constraints we need so that our database is populated with accurate information. 

<br>

### 3. Based on the schema you provide in (1), please write a query to summarize the number of subjects available for each condition.

``` sql
SELECT Conditions.condition_name, COUNT(DISTINCT Subjects.subject_id)
FROM Subjects
JOIN Conditions ON Subjects.condition_id = Conditions.condition_id
GROUP BY Conditions.condition_name;
```

<br>

### 4. Please write a query that returns all melanoma PBMC samples at baseline (time_from_treatment_start is 0) from patients who have treatment tr1.


``` sql
SELECT * FROM Samples

JOIN Subjects ON Samples.subject_id=Subjects.subject_id
JOIN Conditions ON Subjects.condition_id=Conditions.condition_id
JOIN Treatments ON Samples.treatment_id=Treatments.treatment_id
WHERE Conditions.condition_name = 'melanoma' AND Samples.sample_type = 'PBMC' 
    AND Samples.time_from_treatment_start =0 AND Treatments.treatment_name = 'tr1';

```


<br>

### 5. Building on (4)

#### a. How many samples from each project

```sql

SELECT Projects.project_name, COUNT(Samples.sample_id) AS sample_count 
FROM Samples
JOIN Subjects ON Samples.subject_id=Subjects.subject_id
JOIN Conditions ON Subjects.condition_id=Conditions.condition_id
JOIN Treatments ON Samples.treatment_id=Treatments.treatment_id
JOIN Projects ON Samples.project_id=Projects.project_id
WHERE Conditions.condition_name = 'melanoma' AND Samples.sample_type = 'PBMC' 
    AND Samples.time_from_treatment_start =0 AND Treatments.treatment_name = 'tr1'
GROUP BY Projects.project_name

```

#### b. How many responders/non-responders

```sql
SELECT Samples.response, COUNT(Samples.sample_id) AS sample_count 
FROM Samples
JOIN Subjects ON Samples.subject_id=Subjects.subject_id
JOIN Conditions ON Subjects.condition_id=Conditions.condition_id
JOIN Treatments ON Samples.treatment_id=Treatments.treatment_id
WHERE Conditions.condition_name = 'melanoma' AND Samples.sample_type = 'PBMC' 
    AND Samples.time_from_treatment_start =0 AND Treatments.treatment_name = 'tr1'
GROUP BY Samples.response

```

#### c. How many males, females

```sql

SELECT Subjects.sex, COUNT(Samples.sample_id) AS sample_count 
FROM Samples
JOIN Subjects ON Samples.subject_id=Subjects.subject_id
JOIN Conditions ON Subjects.condition_id=Conditions.condition_id
JOIN Treatments ON Samples.treatment_id=Treatments.treatment_id
WHERE Conditions.condition_name = 'melanoma' AND Samples.sample_type = 'PBMC' 
    AND Samples.time_from_treatment_start =0 AND Treatments.treatment_name = 'tr1'
GROUP BY Subjects.sex

```