CREATE DATABASE cell_db;
\c cell_db

CREATE TABLE Projects (
    project_id SERIAL PRIMARY KEY,
    project_name VARCHAR(255) NOT NULL
);

CREATE TABLE Conditions (
    condition_id SERIAL PRIMARY KEY,
	
    condition_name VARCHAR(255) NOT NULL
);


CREATE TABLE Subjects (
    subject_id SERIAL PRIMARY KEY,
	
    subject_num VARCHAR(255) NOT NULL,
    age int,
    sex VARCHAR(1), 
	
    condition_id int REFERENCES Conditions(condition_id)
);


CREATE TABLE Treatments (
    treatment_id SERIAL PRIMARY KEY,
	
    treatment_name VARCHAR(255)
);

CREATE TABLE Samples (
    sample_id SERIAL PRIMARY KEY,
	
    sample_num VARCHAR(255) UNIQUE NOT NULL,
    sample_type VARCHAR(255),
    time_from_treatment_start int,
    response VARCHAR(1),
	
	project_id int REFERENCES Projects(project_id),
    subject_id int REFERENCES Subjects(subject_id),
    treatment_id int REFERENCES Treatments(treatment_id)
);

CREATE TABLE Counts (
    cell_count_id SERIAL PRIMARY KEY,
	
    b_cell int,
    cd8_t_cell int,
    cd4_t_cell int,
    nk_cell int,
    monocyte int,
	
	sample_id int REFERENCES Samples(sample_id)
);
